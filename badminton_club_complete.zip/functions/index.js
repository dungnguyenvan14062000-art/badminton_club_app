// functions/index.js
const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

exports.notifyOnNewEvent = functions.firestore
  .document('events/{eventId}')
  .onCreate(async (snap, context) => {
    const data = snap.data();
    const title = data.title || 'Buổi chơi mới';
    let whenStr = '';
    if (data.when && data.when._seconds) {
      const when = new Date(data.when._seconds * 1000);
      whenStr = when.toLocaleString();
    }
    
    const payload = {
      notification: {
        title: `Buổi chơi: ${title}`,
        body: `Thời gian: ${whenStr} • ${data.location || ''}`,
      },
      data: { eventId: context.params.eventId },
      android: {
        notification: {
          click_action: 'FLUTTER_NOTIFICATION_CLICK'
        }
      }
    };

    try {
      const response = await admin.messaging().sendToTopic('club_updates', payload);
      console.log('Sent message:', response);
    } catch (err) {
      console.error('Error sending message:', err);
    }
    return null;
  });
