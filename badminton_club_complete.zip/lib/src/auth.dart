// lib/src/auth.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'home_page.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class AuthGate extends StatefulWidget {
  @override
  _AuthGateState createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _auth.authStateChanges().listen((user) {
      if (user != null) {
        _ensureUserDoc(user);
        _configureFCM();
      }
    });
  }

  Future<void> _ensureUserDoc(User user) async {
    final doc = FirebaseFirestore.instance.collection('users').doc(user.uid);
    final snapshot = await doc.get();
    if (!snapshot.exists) {
      await doc.set({
        'name': user.displayName ?? 'No name',
        'email': user.email,
        'photoUrl': user.photoURL,
        'joinedAt': FieldValue.serverTimestamp(),
        'joinCount': 0,
      });
    }
  }

  Future<void> _configureFCM() async {
    final fcm = FirebaseMessaging.instance;
    await fcm.requestPermission();
    await fcm.subscribeToTopic('club_updates');

    FirebaseMessaging.onMessage.listen((message) {
      print('FCM foreground: ${message.notification?.title}');
    });
  }

  Future<UserCredential?> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) return null;
    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    return await _auth.signInWithCredential(credential);
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: _auth.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return Scaffold(body: Center(child: CircularProgressIndicator()));
        final user = snapshot.data;
        if (user == null) {
          return Scaffold(
            appBar: AppBar(title: Text('Đăng nhập')),
            body: Center(
              child: ElevatedButton.icon(
                icon: Icon(Icons.login),
                label: Text('Đăng nhập bằng Google'),
                onPressed: () async => await signInWithGoogle(),
              ),
            ),
          );
        }
        return HomePage(user: user);
      },
    );
  }
}


FirebaseMessaging.onMessageOpenedApp.listen((message) {
  final data = message.data;
  final eventId = data['eventId'] ?? '';
  if (eventId.isNotEmpty) {
    // attempt to open deep link
    launchUrl(Uri.parse('badmintonclub://event/$eventId'));
  }
});
