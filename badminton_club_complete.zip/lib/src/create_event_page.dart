// lib/src/create_event_page.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class CreateEventPage extends StatefulWidget {
  final User user;
  CreateEventPage({required this.user});
  @override
  _CreateEventPageState createState() => _CreateEventPageState();
}

class _CreateEventPageState extends State<CreateEventPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleC = TextEditingController();
  final _locC = TextEditingController();
  DateTime _when = DateTime.now().add(Duration(days: 1));
  final eventsRef = FirebaseFirestore.instance.collection('events');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tạo buổi chơi')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(controller: _titleC, decoration: InputDecoration(labelText: 'Tiêu đề'), validator: (v) => v == null || v.isEmpty ? 'Nhập tiêu đề' : null),
              TextFormField(controller: _locC, decoration: InputDecoration(labelText: 'Địa điểm'), validator: (v) => v == null || v.isEmpty ? 'Nhập địa điểm' : null),
              SizedBox(height: 12),
              ListTile(title: Text('Thời gian: ${DateFormat('yyyy-MM-dd HH:mm').format(_when)}'), trailing: Icon(Icons.calendar_today), onTap: _pickDateTime),
              SizedBox(height: 12),
              ElevatedButton(child: Text('Tạo'), onPressed: _create),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickDateTime() async {
    final date = await showDatePicker(context: context, initialDate: _when, firstDate: DateTime.now(), lastDate: DateTime.now().add(Duration(days: 365)));
    if (date == null) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_when));
    if (time == null) return;
    setState(() {
      _when = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    });
  }

  Future<void> _create() async {
    if (!_formKey.currentState!.validate()) return;
    final doc = await eventsRef.add({
      'title': _titleC.text.trim(),
      'location': _locC.text.trim(),
      'when': Timestamp.fromDate(_when),
      'createdBy': widget.user.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'participants': [widget.user.uid],
    });
    await FirebaseFirestore.instance.collection('users').doc(widget.user.uid).update({'joinCount': FieldValue.increment(1)});
    Navigator.pop(context);
  }
}
