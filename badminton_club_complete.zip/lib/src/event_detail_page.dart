// lib/src/event_detail_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class EventDetailPage extends StatelessWidget {
  final String eventId;
  final Map<String, dynamic> eventData;
  EventDetailPage({required this.eventId, required this.eventData});

  @override
  Widget build(BuildContext context) {
    final when = (eventData['when'] as Timestamp).toDate();
    final participants = List<String>.from(eventData['participants'] ?? []);
    return Scaffold(
      appBar: AppBar(title: Text(eventData['title'] ?? 'Buổi chơi')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Thời gian: ${DateFormat('yyyy-MM-dd HH:mm').format(when)}', style: TextStyle(fontSize: 16)),
            SizedBox(height: 8),
            Text('Địa điểm: ${eventData['location'] ?? '-'}', style: TextStyle(fontSize: 16)),
            SizedBox(height: 16),
            Text('Người tham gia:', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Expanded(
              child: participants.isEmpty
                  ? Text('Chưa có người tham gia')
                  : StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance.collection('users').where(FieldPath.documentId, whereIn: participants.isEmpty ? [''] : participants).snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) return SizedBox();
                        final users = snapshot.data!.docs;
                        return ListView(children: users.map((u) {
                          final d = u.data()! as Map<String, dynamic>;
                          return ListTile(
                            leading: CircleAvatar(backgroundImage: NetworkImage(d['photoUrl'] ?? '')),
                            title: Text(d['name'] ?? ''),
                            subtitle: Text('Đã tham gia ${d['joinCount'] ?? 0} buổi'),
                          );
                        }).toList());
                      },
                    ),
            )
          ],
        ),
      ),
    );
  }
}
