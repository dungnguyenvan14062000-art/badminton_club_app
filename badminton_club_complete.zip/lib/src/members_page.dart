// lib/src/members_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MembersPage extends StatelessWidget {
  final usersRef = FirebaseFirestore.instance.collection('users');
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Thành viên')),
      body: StreamBuilder<QuerySnapshot>(
        stream: usersRef.orderBy('joinCount', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final d = docs[index];
              final data = d.data()! as Map<String, dynamic>;
              return ListTile(
                leading: CircleAvatar(backgroundImage: NetworkImage(data['photoUrl'] ?? '')),
                title: Text(data['name'] ?? ''),
                subtitle: Text('Đã tham gia ${data['joinCount'] ?? 0} buổi'),
              );
            },
          );
        },
      ),
    );
  }
}
