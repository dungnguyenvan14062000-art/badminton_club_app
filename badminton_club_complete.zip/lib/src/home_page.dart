// lib/src/home_page.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'create_event_page.dart';
import 'event_detail_page.dart';
import 'members_page.dart';

class HomePage extends StatefulWidget {
  final User user;
  HomePage({required this.user});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final eventsRef = FirebaseFirestore.instance.collection('events');
  final usersRef = FirebaseFirestore.instance.collection('users');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('CLB Cầu Lông'),
        actions: [IconButton(icon: Icon(Icons.logout), onPressed: () async => await FirebaseAuth.instance.signOut())],
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                accountName: Text(widget.user.displayName ?? ''),
                accountEmail: Text(widget.user.email ?? ''),
                currentAccountPicture: CircleAvatar(backgroundImage: NetworkImage(widget.user.photoURL ?? '')),
              ),
              ListTile(leading: Icon(Icons.people), title: Text('Thành viên'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MembersPage()))),
            ],
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: eventsRef.orderBy('when', descending: false).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                if (docs.isEmpty) return Center(child: Text('Chưa có buổi chơi nào. Tạo ngay!'));
                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final d = docs[index];
                    final data = d.data()! as Map<String, dynamic>;
                    final when = (data['when'] as Timestamp).toDate();
                    final participants = List<String>.from(data['participants'] ?? []);
                    final joined = participants.contains(widget.user.uid);
                    return Card(
                      margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: ListTile(
                        title: Text(data['title'] ?? 'Buổi chơi'),
                        subtitle: Text('${DateFormat('yyyy-MM-dd HH:mm').format(when)} • ${data['location'] ?? ''}'),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('${participants.length} tham gia'),
                            SizedBox(height: 6),
                            ElevatedButton(child: Text(joined ? 'Huỷ' : 'Tham gia'), onPressed: () => _toggleJoin(d.id, joined)),
                          ],
                        ),
                        onTap: () => _openEventDetail(d.id, data),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(child: Icon(Icons.add), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CreateEventPage(user: widget.user)))),
    );
  }

  Future<void> _toggleJoin(String eventId, bool currentlyJoined) async {
    final doc = eventsRef.doc(eventId);
    final uid = widget.user.uid;
    if (currentlyJoined) {
      await doc.update({'participants': FieldValue.arrayRemove([uid])});
      await usersRef.doc(uid).update({'joinCount': FieldValue.increment(-1)});
    } else {
      await doc.update({'participants': FieldValue.arrayUnion([uid])});
      await usersRef.doc(uid).update({'joinCount': FieldValue.increment(1)});
    }
  }

  void _openEventDetail(String eventId, Map<String, dynamic> data) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => EventDetailPage(eventId: eventId, eventData: data)));
  }
}
