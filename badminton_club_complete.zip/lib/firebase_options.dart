// lib/firebase_options.dart
// Placeholder: generate real file by running `flutterfire configure`.
class DefaultFirebaseOptions {
  static get currentPlatform => null;
}
